﻿using FunBooksAndVideos.Infrastructure.Entities;
using FunBooksAndVideos.WebApi.Infrastructure.Database;
using System;
using System.Linq;

namespace FunBooksAndVideos.WebApi
{
    public static class DbSeeder
    {
        public static void Seed(DatabaseContext context)
        {
            if (!context.Set<OrderEntity>().Any())
            {
                context.Set<OrderEntity>().AddRange(
                    new OrderEntity { Id = "1", Customer_ID = "1011", Date = DateTime.Now.AddDays(-3), price = 5001 },
                    new OrderEntity { Id = "2", Customer_ID = "102", Date = DateTime.Now.AddDays(-2), price = 900 },
                    new OrderEntity { Id = "3", Customer_ID = "103", Date = DateTime.Now.AddDays(-1), price = 1200 }
                );

                context.SaveChanges();
            }

            if (!context.Set<ProductEntity>().Any())
            {
                context.Set<ProductEntity>().AddRange(
                    new ProductEntity
                    {
                        Id = "P1001",
                        Name = "Wireless Mouse",
                        Barcode = "890100000001",
                        IsActive = true,
                        Description = "2.4G Wireless ergonomic mouse",
                        price = 599.00M,
                        Category = "Electronics"
                    },
                    new ProductEntity
                    {
                        Id = "P1002",
                        Name = "Mechanical Keyboard",
                        Barcode = "890100000002",
                        IsActive = true,
                        Description = "RGB backlit mechanical keyboard",
                        price = 2499.00M,
                        Category = "Electronics"
                    },
                    new ProductEntity
                    {
                        Id = "P1003",
                        Name = "Gaming Headset",
                        Barcode = "890100000003",
                        IsActive = true,
                        Description = "Noise cancelling gaming headset",
                        price = 1899.00M,
                        Category = "Accessories"
                    },
                    new ProductEntity
                    {
                        Id = "P1004",
                        Name = "USB-C Charger",
                        Barcode = "890100000004",
                        IsActive = true,
                        Description = "Fast charging USB-C adapter",
                        price = 999.00M,
                        Category = "Electronics"
                    },
                    new ProductEntity
                    {
                        Id = "P1005",
                        Name = "Laptop Stand",
                        Barcode = "890100000005",
                        IsActive = true,
                        Description = "Adjustable aluminum laptop stand",
                        price = 1299.00M,
                        Category = "Office"
                    }
                );

                context.SaveChanges();
            }



        }
    }

}
